package com.emailsender.sendemail;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.springframework.boot.SpringApplication;

public class EmailForm {
	public static String email;
	public static String subject;
	public static String msg;
	private JFrame frame;
	private JTextField txt_email;
	private JTextField txt_subject;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EmailForm window = new EmailForm();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public EmailForm() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Email Address:");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel.setBounds(10, 10, 94, 13);
		frame.getContentPane().add(lblNewLabel);
		
		txt_email = new JTextField();
		txt_email.setBounds(114, 8, 291, 19);
		frame.getContentPane().add(txt_email);
		txt_email.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Compose Mail:");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_1.setBounds(10, 90, 110, 16);
		frame.getContentPane().add(lblNewLabel_1);
		
		txt_subject = new JTextField();
		txt_subject.setBounds(114, 53, 291, 19);
		frame.getContentPane().add(txt_subject);
		txt_subject.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("Subject:");
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_1_1.setBounds(10, 53, 54, 16);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JTextArea txt_message = new JTextArea();
		txt_message.setBounds(114, 90, 291, 135);
		frame.getContentPane().add(txt_message);
		
		JButton btnNewButton = new JButton("Send Mail");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				email= txt_email.getText();
				subject=txt_subject.getText();
				msg=txt_message.getText();
				SpringApplication.run(SendemailApplication.class, new String[0]); 
				JOptionPane.showMessageDialog(null, "Message Sent Successfully");
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 10));
		btnNewButton.setBounds(189, 235, 85, 21);
		frame.getContentPane().add(btnNewButton);
		
		
	}
}
